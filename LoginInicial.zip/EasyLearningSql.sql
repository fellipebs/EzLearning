create database EasyLearning;
use EasyLearning;

CREATE TABLE `usuarios` (
  `Codigo` int(10) UNSIGNED auto_increment primary key NOT NULL,
  `Usuario` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `Login` varchar(20) NOT NULL,
  `Senha` varchar(50) NOT NULL,
  `foto` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

drop table usuarios;