<?php
//Comando para conexão com o banco de dados.
$con =  new PDO("mysql:host=localhost; dbname=EasyLearning","root","");


?>