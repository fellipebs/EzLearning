<?php

class cadastro{

    public function cadastrar(){
        $pdo = new PDO("mysql:host=localhost; dbname=EasyLearning;", "root", "");

        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
           
        $stmt = $pdo->prepare('INSERT INTO usuarios (Usuario, email, Login, Senha, foto) VALUES(:Usuario, :email, :Login, md5(:Senha), :foto )');
        $stmt->execute(array(
          ':Usuario' => $usuario,
          ':email' => $email,
          ':Login' => $login,
          ':Senha' => $senha,
          ':foto' => $new_name
          
        ));
    }





}


?>